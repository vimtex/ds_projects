This contains the Doubletalk package as used throughout
part 2.  Create a directory called 'doubletalk' on your
Python path and copy the contents of the doubletalk
folder into it.  Then double-click the script
comservers.py to register them.

Apart from comservers.py, the rest should run fine on
other platforms.
