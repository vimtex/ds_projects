AR 19:08 18/04/98

The doubletalk package.
This is the stuff used over the last two years tidied up
according to the interfaces in the docs I'm writing.
Put it in a directory called 'doubletalk' which is under your
python path.
