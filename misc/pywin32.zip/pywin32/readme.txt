This archive contains all the sample code from:

Python Programming on Win32

All samples are organized by chapter, with each chapter's samples
in its own directory.  Chapters without samples are not listed.

The 'PyDelphi' tool (discussed in Chapter 22 - Extending and Embedding)
is not in this archive, but can be found in PyDelphi.zip

The official web page for the book is at
http://starship.python.net/crew/mhammond/ppw32

Please see this site for updates and more information about the examples.

Any comments or bugs, please mail either:
Mark Hammond <mhammond@skippinet.com.au>
Andy Robinson <andy@robanal.demon.co.uk>