import sys
sys.path.append( "d:\users\morgan\pythonEngine\lib\delphi")
