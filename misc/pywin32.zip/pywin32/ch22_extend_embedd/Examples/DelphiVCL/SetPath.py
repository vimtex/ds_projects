import sys
sys.path.append("D:\Data\Project\OReilly\chxx_extendembed\examples\delphivcl\lib")


