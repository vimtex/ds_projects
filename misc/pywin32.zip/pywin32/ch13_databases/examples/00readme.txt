Th database pydbdemos.mdb contains data used for the examples in Chapter 13.
It should be configured as an ODBC data source named 'PYDBDEMOS'
