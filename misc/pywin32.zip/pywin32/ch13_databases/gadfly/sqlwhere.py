
'''this module indicates where the sql datastructures are marshalled
   Auto generated on install: better not touch!
'''

filename = 'D:\\Data\\Project\\OReilly\\ch13_Databases\\gadfly\\sql.mar'
